package com.example.autotrapdoor;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.logging.Level;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

public class AutoTrapdoorClient implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("autotrapdoor");

    /** always = luôn chạy | unfocused = chỉ chạy khi cửa sổ này KHÔNG được focus | focused = chỉ khi đang focus */
    private static volatile String mode = "always";

    /** look = chọn cửa sập gần tâm màn hình nhất (nhắm vào cái muốn đóng) | nearest = gần người nhất */
    private static volatile String select = "look";

    /** Mic: on = tự đóng khi mic nghe âm thanh đủ to | off = tắt */
    private static volatile boolean micOn = true;
    /** Ngưỡng biên độ đỉnh, 0..1 (config ghi theo %, mặc định 30%). */
    private static volatile double micThreshold = 0.30;
    /** Sau mỗi lần kích hoạt, bỏ qua trong khoảng này (ms). */
    private static volatile long micCooldownMs = 400L;
    /** Tên (một phần) của mic muốn dùng; để trống = mic mặc định. */
    private static volatile String micDevice = "";
    /** on = ghi log mức âm lượng mic mỗi giây để chỉnh ngưỡng. */
    private static volatile boolean micDebug = false;

    @Override
    public void onInitializeClient() {
        final int keyCode = loadKeyCode();
        Thread t = new Thread(() -> startGlobalHook(keyCode), "AutoTrapdoor-Hook");
        t.setDaemon(true);
        t.start();

        if (micOn) {
            Thread m = new Thread(AutoTrapdoorClient::micLoop, "AutoTrapdoor-Mic");
            m.setDaemon(true);
            m.setPriority(Thread.MAX_PRIORITY);
            m.start();
        }
    }

    /** Đọc phím từ config/autotrapdoor.properties (mặc định F8). */
    private int loadKeyCode() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("autotrapdoor.properties");
        Properties props = new Properties();
        try {
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) { props.load(in); }
            } else {
                props.setProperty("key", "F8");
                props.setProperty("mode", "always");
                props.setProperty("select", "look");
                props.setProperty("mic", "on");
                props.setProperty("mic_threshold", "30");
                props.setProperty("mic_cooldown_ms", "400");
                props.setProperty("mic_device", "");
                props.setProperty("mic_debug", "off");
                try (OutputStream out = Files.newOutputStream(file)) {
                    props.store(out, "Phim kich hoat: F1-F12, Z, X, C, V, B, INSERT, HOME, ... (ten theo VC_xxx cua JNativeHook)");
                }
            }
            mode = props.getProperty("mode", "always").trim().toLowerCase();
            select = props.getProperty("select", "look").trim().toLowerCase();
            micOn = isOn(props.getProperty("mic", "on"), true);
            micDebug = isOn(props.getProperty("mic_debug", "off"), false);
            micDevice = props.getProperty("mic_device", "").trim();
            micThreshold = Math.max(0.0, Math.min(100.0, parseNum(props.getProperty("mic_threshold"), 30.0))) / 100.0;
            micCooldownMs = (long) Math.max(0.0, parseNum(props.getProperty("mic_cooldown_ms"), 400.0));
            String name = props.getProperty("key", "F8").trim().toUpperCase();
            return NativeKeyEvent.class.getField("VC_" + name).getInt(null);
        } catch (Exception e) {
            LOG.warn("Khong doc duoc phim trong config, dung F8 mac dinh: {}", e.toString());
            return NativeKeyEvent.VC_F8;
        }
    }

    private void startGlobalHook(int keyCode) {
        try {
            // Tắt log ồn của JNativeHook
            java.util.logging.Logger jl = java.util.logging.Logger.getLogger(GlobalScreen.class.getPackage().getName());
            jl.setLevel(Level.OFF);
            jl.setUseParentHandlers(false);

            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(new NativeKeyListener() {
                @Override
                public void nativeKeyPressed(NativeKeyEvent e) {
                    if (e.getKeyCode() == keyCode) {
                        // execute() chạy ngay ở luồng chính -> độ trễ thấp nhất
                        MinecraftClient.getInstance().execute(AutoTrapdoorClient::closeNearestTrapdoor);
                    }
                }
            });
            LOG.info("Auto Trapdoor: da dang ky phim toan cuc.");
        } catch (Throwable e) {
            LOG.error("Auto Trapdoor: khong the dang ky phim toan cuc", e);
        }
    }

    private static void closeNearestTrapdoor() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.interactionManager == null) return;

        if (!modeAllows(mc)) return;

        double reach = player.getBlockInteractionRange();
        double reachSq = reach * reach;
        Vec3d eye = player.getEyePos();
        int r = (int) Math.ceil(reach);
        BlockPos base = player.getBlockPos();

        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        boolean byLook = select.equals("look");
        Vec3d look = player.getRotationVec(1.0f).normalize();

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockState s = world.getBlockState(pos);
                    if (!(s.getBlock() instanceof TrapdoorBlock)) continue;
                    if (s.isOf(Blocks.IRON_TRAPDOOR)) continue;      // không mở bằng tay được
                    if (!s.get(TrapdoorBlock.OPEN)) continue;        // chỉ cửa đang mở
                    double d = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (d > reachSq) continue;
                    double score = d;
                    if (byLook) {
                        Vec3d to = Vec3d.ofCenter(pos).subtract(eye);
                        double len = Math.max(to.length(), 1.0E-6);
                        // 0 = nằm đúng tâm màn hình; cộng thêm khoảng cách rất nhỏ để phá hòa
                        score = (1.0 - look.dotProduct(to) / len) + d * 1.0E-6;
                    }
                    if (score >= bestScore) continue;
                    bestScore = score;
                    best = pos;
                }
            }
        }

        if (best == null) return;
        interact(mc, player, best);
    }

    /** mode=always/unfocused/focused áp dụng cho cả phím lẫn âm thanh. */
    private static boolean modeAllows(MinecraftClient mc) {
        boolean focused = mc.isWindowFocused();
        if (mode.equals("unfocused") && focused) return false;   // acc chính đang focus -> bỏ qua
        if (mode.equals("focused") && !focused) return false;
        return true;
    }

    /** Gửi 1 lần tương tác (đóng/mở) vào cửa sập tại pos. */
    private static void interact(MinecraftClient mc, ClientPlayerEntity player, BlockPos pos) {
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
        ActionResult result = mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) player.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------------ MIC

    private static boolean isOn(String v, boolean def) {
        if (v == null) return def;
        v = v.trim().toLowerCase();
        if (v.equals("on") || v.equals("true") || v.equals("1")) return true;
        if (v.equals("off") || v.equals("false") || v.equals("0")) return false;
        return def;
    }

    private static double parseNum(String v, double def) {
        try { return v == null ? def : Double.parseDouble(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    /** Mở mic: thử 44.1k / 48k / 16k, 16-bit mono. Trả null nếu không mở được. */
    private static TargetDataLine openMic(float rate) {
        try {
            AudioFormat fmt = new AudioFormat(rate, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, fmt);
            TargetDataLine line = null;
            String want = micDevice.toLowerCase();
            if (!want.isEmpty()) {
                for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                    if (!mi.getName().toLowerCase().contains(want)) continue;
                    Mixer mx = AudioSystem.getMixer(mi);
                    if (mx.isLineSupported(info)) {
                        line = (TargetDataLine) mx.getLine(info);
                        LOG.info("Auto Trapdoor: dung mic '{}'", mi.getName());
                        break;
                    }
                }
            }
            if (line == null) {
                if (!AudioSystem.isLineSupported(info)) return null;
                line = (TargetDataLine) AudioSystem.getLine(info);
                LOG.info("Auto Trapdoor: dung mic mac dinh cua he thong");
            }
            int chunk = ((int) (rate * 0.010)) * 2;      // 10ms
            line.open(fmt, chunk * 4);                   // buffer nho -> do tre thap
            line.start();
            return line;
        } catch (Throwable e) {
            LOG.warn("Auto Trapdoor: khong mo duoc mic o {} Hz: {}", rate, e.toString());
            return null;
        }
    }

    /** Luồng nghe mic: mỗi khối 10ms, đỉnh >= ngưỡng -> chạy cùng đường với phím (luồng chính). */
    private static void micLoop() {
        try {
            if (micDebug) {
                for (Mixer.Info mi : AudioSystem.getMixerInfo()) LOG.info("Auto Trapdoor: thiet bi am thanh: '{}'", mi.getName());
            }
            TargetDataLine line = null;
            for (float rate : new float[] {44100f, 48000f, 16000f}) {
                line = openMic(rate);
                if (line != null) break;
            }
            if (line == null) {
                LOG.error("Auto Trapdoor: khong mo duoc mic nao (kiem tra quyen Microphone cua he dieu hanh).");
                return;
            }
            AudioFormat fmt = line.getFormat();
            byte[] buf = new byte[((int) (fmt.getSampleRate() * 0.010)) * 2];
            boolean armed = true;
            long lastTrigger = 0L;
            long dbgT = System.nanoTime();
            int dbgPeak = 0;
            LOG.info("Auto Trapdoor: dang nghe mic ({} Hz, nguong {}%).", (int) fmt.getSampleRate(), Math.round(micThreshold * 100));

            while (true) {
                int n = line.read(buf, 0, buf.length);
                if (n <= 0) {
                    if (!line.isOpen()) break;
                    continue;
                }
                int peak = 0;
                for (int i = 0; i + 1 < n; i += 2) {
                    int v = (short) ((buf[i + 1] << 8) | (buf[i] & 0xFF));
                    if (v < 0) v = -v;
                    if (v > peak) peak = v;
                }
                double level = peak / 32768.0;
                long now = System.nanoTime();

                if (micDebug) {
                    if (peak > dbgPeak) dbgPeak = peak;
                    if (now - dbgT >= 1_000_000_000L) {
                        LOG.info("Auto Trapdoor mic: dinh {}% (nguong {}%)", Math.round(dbgPeak / 327.68), Math.round(micThreshold * 100));
                        dbgPeak = 0;
                        dbgT = now;
                    }
                }

                if (level < micThreshold * 0.5) armed = true;   // im lai -> cho phep kich hoat lai
                if (armed && level >= micThreshold && now - lastTrigger >= micCooldownMs * 1_000_000L) {
                    armed = false;
                    lastTrigger = now;
                    MinecraftClient.getInstance().execute(AutoTrapdoorClient::closeNearestTrapdoor);
                }
            }
        } catch (Throwable e) {
            LOG.error("Auto Trapdoor: loi luong mic", e);
        }
    }
}
