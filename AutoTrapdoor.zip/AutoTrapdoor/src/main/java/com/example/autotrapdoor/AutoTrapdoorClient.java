package com.example.autotrapdoor;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.logging.Level;

public class AutoTrapdoorClient implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("autotrapdoor");

    /** always = luôn chạy | unfocused = chỉ chạy khi cửa sổ này KHÔNG được focus | focused = chỉ khi đang focus */
    private static volatile String mode = "always";

    @Override
    public void onInitializeClient() {
        final int keyCode = loadKeyCode();
        Thread t = new Thread(() -> startGlobalHook(keyCode), "AutoTrapdoor-Hook");
        t.setDaemon(true);
        t.start();
    }

    /** Đọc phím từ config/autotrapdoor.properties (mặc định F8). */
    private int loadKeyCode() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("autotrapdoor.properties");
        Properties props = new Properties();
        try {
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) { props.load(in); }
            } else {
                props.setProperty("key", "F8");
                props.setProperty("mode", "always");
                try (OutputStream out = Files.newOutputStream(file)) {
                    props.store(out, "Phim kich hoat: F1-F12, Z, X, C, V, B, INSERT, HOME, ... (ten theo VC_xxx cua JNativeHook)");
                }
            }
            mode = props.getProperty("mode", "always").trim().toLowerCase();
            String name = props.getProperty("key", "F8").trim().toUpperCase();
            return NativeKeyEvent.class.getField("VC_" + name).getInt(null);
        } catch (Exception e) {
            LOG.warn("Khong doc duoc phim trong config, dung F8 mac dinh: {}", e.toString());
            return NativeKeyEvent.VC_F8;
        }
    }

    private void startGlobalHook(int keyCode) {
        try {
            // Tắt log ồn của JNativeHook
            java.util.logging.Logger jl = java.util.logging.Logger.getLogger(GlobalScreen.class.getPackage().getName());
            jl.setLevel(Level.OFF);
            jl.setUseParentHandlers(false);

            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(new NativeKeyListener() {
                @Override
                public void nativeKeyPressed(NativeKeyEvent e) {
                    if (e.getKeyCode() == keyCode) {
                        // execute() chạy ngay ở luồng chính -> độ trễ thấp nhất
                        MinecraftClient.getInstance().execute(AutoTrapdoorClient::closeNearestTrapdoor);
                    }
                }
            });
            LOG.info("Auto Trapdoor: da dang ky phim toan cuc.");
        } catch (Throwable e) {
            LOG.error("Auto Trapdoor: khong the dang ky phim toan cuc", e);
        }
    }

    private static void closeNearestTrapdoor() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.interactionManager == null) return;

        boolean focused = mc.isWindowFocused();
        if (mode.equals("unfocused") && focused) return;   // acc chính đang focus -> bỏ qua
        if (mode.equals("focused") && !focused) return;

        double reach = player.getBlockInteractionRange();
        double reachSq = reach * reach;
        Vec3d eye = player.getEyePos();
        int r = (int) Math.ceil(reach);
        BlockPos base = player.getBlockPos();

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockState s = world.getBlockState(pos);
                    if (!(s.getBlock() instanceof TrapdoorBlock)) continue;
                    if (s.isOf(Blocks.IRON_TRAPDOOR)) continue;      // không mở bằng tay được
                    if (!s.get(TrapdoorBlock.OPEN)) continue;        // chỉ cửa đang mở
                    double d = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (d > reachSq || d >= bestDist) continue;
                    bestDist = d;
                    best = pos;
                }
            }
        }

        if (best == null) return;

        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(best), Direction.UP, best, false);
        ActionResult result = mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) player.swingHand(Hand.MAIN_HAND);
    }
}
