package com.example.autotrapdoor;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

public class AutoTrapdoorClient implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("autotrapdoor");

    /** always = luôn chạy | unfocused = chỉ chạy khi cửa sổ này KHÔNG được focus | focused = chỉ khi đang focus */
    static volatile String mode = "always";

    /** look = chọn cửa sập gần tâm màn hình nhất (nhắm vào cái muốn đóng) | nearest = gần người nhất */
    static volatile String select = "look";

    /** Mic: on = tự đóng khi mic nghe âm thanh đủ to | off = tắt (đổi trong config có hiệu lực ngay, không cần thoát game). */
    static volatile boolean micOn = true;
    /** Ngưỡng biên độ đỉnh, 0..1 (config ghi theo %, mặc định 30%). */
    static volatile double micThreshold = 0.30;
    /** Sau mỗi lần kích hoạt, bỏ qua trong khoảng này (ms). */
    static volatile long micCooldownMs = 300L;
    /** Âm phải liên tục >= ngưỡng ít nhất N ms mới kích hoạt (0 = tắt). Lọc tiếng động ngắn. */
    static volatile long micMinMs = 0L;
    /** Nếu lúc nghe thấy mà chưa có cửa sập mở, tiếp tục thử lại trong N ms (0 = không thử lại). */
    static volatile long micRetryMs = 200L;
    /** Tên (một phần) của mic muốn dùng; để trống = mic mặc định. */
    static volatile String micDevice = "";
    /** on = ghi log mức âm lượng mic mỗi giây. */
    private static volatile boolean micDebug = false;
    /** on = hiện mức mic theo thời gian thực trên thanh action bar để chỉnh ngưỡng. */
    private static volatile boolean micMeter = false;

    /** Hạn thử lại (nanoTime), 0 = không đang chờ. */
    private static volatile long pendingUntil = 0L;
    /** Mic đang mở + thời điểm nhận khối âm thanh gần nhất (cho watchdog). */
    private static volatile TargetDataLine activeLine = null;
    private static volatile long lastChunkNanos = 0L;
    /** lastModified của file config lần đọc gần nhất. */
    private static volatile long cfgStamp = 0L;

    /** Phím mở màn hình cấu hình (JNativeHook keycode), -1 = tắt. */
    private static volatile int guiKeyCode = NativeKeyEvent.VC_F7;
    /** Đỉnh âm lượng lớn nhất kể từ lần takePeak() gần nhất (bit của double). */
    private static final AtomicLong peakBits = new AtomicLong(0L);
    private static volatile boolean closeErrLogged = false;

    private static final String CFG_COMMENT = "Phim: F1-F12, Z, X, C, V, B, INSERT, HOME, ... (ten theo VC_xxx cua JNativeHook). gui_key=NONE de tat phim mo GUI. Co the mo GUI bang lenh /autotrapdoor";

    @Override
    public void onInitializeClient() {
        final int keyCode = loadKeyCode();
        Thread t = new Thread(() -> startGlobalHook(keyCode), "AutoTrapdoor-Hook");
        t.setDaemon(true);
        t.start();

        // Luôn chạy luồng mic: nó tự rảnh khi mic=off và bật lại khi bạn sửa config.
        Thread m = new Thread(AutoTrapdoorClient::micLoop, "AutoTrapdoor-Mic");
        m.setDaemon(true);
        m.setPriority(Thread.MAX_PRIORITY);
        m.start();

        Thread w = new Thread(AutoTrapdoorClient::micWatchdog, "AutoTrapdoor-MicWatch");
        w.setDaemon(true);
        w.start();

        // /autotrapdoor -> mở màn hình cấu hình (lệnh client, không gửi lên server)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("autotrapdoor").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> mc.setScreen(new ConfigScreen()));   // chạy sau khi chat tự đóng
                    return 1;
                })));
    }

    /** Đọc phím từ config/autotrapdoor.properties (mặc định F8). */
    private int loadKeyCode() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("autotrapdoor.properties");
        Properties props = new Properties();
        try {
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) { props.load(in); }
            } else {
                props.setProperty("key", "F8");
                props.setProperty("gui_key", "F7");
                props.setProperty("mode", "always");
                props.setProperty("select", "look");
                props.setProperty("mic", "on");
                props.setProperty("mic_threshold", "30");
                props.setProperty("mic_cooldown_ms", "300");
                props.setProperty("mic_min_ms", "0");
                props.setProperty("mic_retry_ms", "200");
                props.setProperty("mic_device", "");
                props.setProperty("mic_debug", "off");
                props.setProperty("mic_meter", "off");
                try (OutputStream out = Files.newOutputStream(file)) {
                    props.store(out, CFG_COMMENT);
                }
            }
            applyProps(props);
            try { cfgStamp = Files.getLastModifiedTime(file).toMillis(); } catch (Exception ignored) { }
            guiKeyCode = parseKey(props.getProperty("gui_key", "F7"), NativeKeyEvent.VC_F7);
            String name = props.getProperty("key", "F8").trim().toUpperCase();
            return NativeKeyEvent.class.getField("VC_" + name).getInt(null);
        } catch (Exception e) {
            LOG.warn("Khong doc duoc phim trong config, dung F8 mac dinh: {}", e.toString());
            return NativeKeyEvent.VC_F8;
        }
    }

    private static int parseKey(String raw, int def) {
        String n = raw == null ? "" : raw.trim().toUpperCase();
        if (n.equals("NONE") || n.equals("OFF")) return -1;
        try {
            return NativeKeyEvent.class.getField("VC_" + n).getInt(null);
        } catch (Exception e) {
            return def;
        }
    }

    /** Áp dụng mọi tuỳ chọn (trừ phím) từ config. Gọi lúc khởi động và mỗi khi file config đổi. */
    private static void applyProps(Properties props) {
        mode = props.getProperty("mode", "always").trim().toLowerCase();
        select = props.getProperty("select", "look").trim().toLowerCase();
        micOn = isOn(props.getProperty("mic", "on"), true);
        micDebug = isOn(props.getProperty("mic_debug", "off"), false);
        micMeter = isOn(props.getProperty("mic_meter", "off"), false);
        micDevice = props.getProperty("mic_device", "").trim();
        micThreshold = Math.max(0.0, Math.min(100.0, parseNum(props.getProperty("mic_threshold"), 30.0))) / 100.0;
        micCooldownMs = (long) Math.max(0.0, parseNum(props.getProperty("mic_cooldown_ms"), 300.0));
        micMinMs = (long) Math.max(0.0, Math.min(1000.0, parseNum(props.getProperty("mic_min_ms"), 0.0)));
        micRetryMs = (long) Math.max(0.0, Math.min(2000.0, parseNum(props.getProperty("mic_retry_ms"), 200.0)));
    }

    /** Sửa file config khi đang chơi: tự đọc lại (kiểm tra ~1 lần/giây). Phím thì vẫn cần khởi động lại. */
    private static void maybeReloadConfig() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("autotrapdoor.properties");
            if (!Files.exists(file)) return;
            long m = Files.getLastModifiedTime(file).toMillis();
            if (m == cfgStamp) return;
            cfgStamp = m;
            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(file)) { props.load(in); }
            applyProps(props);
            LOG.info("Auto Trapdoor: da nap lai config (nguong {}%).", Math.round(micThreshold * 100));
        } catch (Throwable e) {
            LOG.warn("Auto Trapdoor: khong nap lai duoc config: {}", e.toString());
        }
    }

    private void startGlobalHook(int keyCode) {
        try {
            // Tắt log ồn của JNativeHook
            java.util.logging.Logger jl = java.util.logging.Logger.getLogger(GlobalScreen.class.getPackage().getName());
            jl.setLevel(Level.OFF);
            jl.setUseParentHandlers(false);

            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(new NativeKeyListener() {
                @Override
                public void nativeKeyPressed(NativeKeyEvent e) {
                    int c = e.getKeyCode();
                    if (c == keyCode) {
                        // execute() chạy ngay ở luồng chính -> độ trễ thấp nhất
                        MinecraftClient.getInstance().execute(AutoTrapdoorClient::closeSafely);
                    } else if (c == guiKeyCode) {
                        MinecraftClient.getInstance().execute(AutoTrapdoorClient::toggleGui);
                    }
                }
            });
            LOG.info("Auto Trapdoor: da dang ky phim toan cuc.");
        } catch (Throwable e) {
            LOG.error("Auto Trapdoor: khong the dang ky phim toan cuc", e);
        }
    }

    /** @return true nếu đã gửi lệnh vào 1 cửa sập đang mở; false nếu không có cửa nào để đóng. */
    private static boolean closeNearestTrapdoor() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.interactionManager == null) return false;

        if (!modeAllows(mc)) return false;

        double reach = player.getBlockInteractionRange();
        double reachSq = reach * reach;
        Vec3d eye = player.getEyePos();
        int r = (int) Math.ceil(reach);
        BlockPos base = player.getBlockPos();

        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        boolean byLook = select.equals("look");
        Vec3d look = player.getRotationVec(1.0f).normalize();

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockState s = world.getBlockState(pos);
                    if (!(s.getBlock() instanceof TrapdoorBlock)) continue;
                    if (s.isOf(Blocks.IRON_TRAPDOOR)) continue;      // không mở bằng tay được
                    if (!s.get(TrapdoorBlock.OPEN)) continue;        // chỉ cửa đang mở
                    double d = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (d > reachSq) continue;
                    double score = d;
                    if (byLook) {
                        Vec3d to = Vec3d.ofCenter(pos).subtract(eye);
                        double len = Math.max(to.length(), 1.0E-6);
                        // 0 = nằm đúng tâm màn hình; cộng thêm khoảng cách rất nhỏ để phá hòa
                        score = (1.0 - look.dotProduct(to) / len) + d * 1.0E-6;
                    }
                    if (score >= bestScore) continue;
                    bestScore = score;
                    best = pos;
                }
            }
        }

        if (best == null) return false;
        interact(mc, player, best);
        return true;
    }

    /** Như closeNearestTrapdoor nhưng không bao giờ ném exception (chỉ ghi log lần đầu). */
    private static boolean closeSafely() {
        try {
            return closeNearestTrapdoor();
        } catch (Throwable e) {
            if (!closeErrLogged) {
                closeErrLogged = true;
                LOG.error("Auto Trapdoor: loi khi dong cua sap", e);
            }
            return false;
        }
    }

    /** Mở/đóng màn hình cấu hình bằng phím gui_key (chỉ khi cửa sổ game đang focus và không mở màn hình khác). */
    private static void toggleGui() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof ConfigScreen) {
            mc.currentScreen.close();
            return;
        }
        if (!mc.isWindowFocused() || mc.currentScreen != null || mc.player == null) return;
        mc.setScreen(new ConfigScreen());
    }

    /** Ghi toàn bộ tuỳ chọn hiện tại vào file config (giữ nguyên key/gui_key, ghi an toàn qua file tạm). */
    static void saveConfig() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("autotrapdoor.properties");
            Properties props = new Properties();
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) { props.load(in); }
            }
            props.setProperty("mic", micOn ? "on" : "off");
            props.setProperty("mic_threshold", String.valueOf(Math.round(micThreshold * 100.0)));
            props.setProperty("mic_cooldown_ms", String.valueOf(micCooldownMs));
            props.setProperty("mic_min_ms", String.valueOf(micMinMs));
            props.setProperty("mic_retry_ms", String.valueOf(micRetryMs));
            props.setProperty("mic_device", micDevice);
            props.setProperty("mode", mode);
            props.setProperty("select", select);

            Path tmp = file.resolveSibling("autotrapdoor.properties.tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) { props.store(out, CFG_COMMENT); }
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
            cfgStamp = Files.getLastModifiedTime(file).toMillis();
        } catch (Throwable e) {
            LOG.warn("Auto Trapdoor: khong luu duoc config: {}", e.toString());
        }
    }

    /** Danh sách mic thật (hỗ trợ thu 16-bit mono) cho màn hình cấu hình. */
    static List<String> listMics() {
        List<String> out = new ArrayList<>();
        try {
            for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                try {
                    Mixer mx = AudioSystem.getMixer(mi);
                    boolean ok = false;
                    for (float rate : new float[] {44100f, 48000f, 16000f}) {
                        if (mx.isLineSupported(new DataLine.Info(TargetDataLine.class, new AudioFormat(rate, 16, 1, true, false)))) {
                            ok = true;
                            break;
                        }
                    }
                    if (ok && !out.contains(mi.getName())) out.add(mi.getName());
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
        return out;
    }

    static boolean isMicRunning() {
        return activeLine != null;
    }

    /** Đỉnh âm lượng (0..1) lớn nhất kể từ lần gọi trước; đặt lại về 0. */
    static double takePeak() {
        return Double.longBitsToDouble(peakBits.getAndSet(0L));
    }

    private static void publishPeak(double level) {
        long nb = Double.doubleToLongBits(level);
        peakBits.accumulateAndGet(nb, (a, b) -> Double.longBitsToDouble(a) >= Double.longBitsToDouble(b) ? a : b);
    }

    /** mode=always/unfocused/focused áp dụng cho cả phím lẫn âm thanh. */
    private static boolean modeAllows(MinecraftClient mc) {
        boolean focused = mc.isWindowFocused();
        if (mode.equals("unfocused") && focused) return false;   // acc chính đang focus -> bỏ qua
        if (mode.equals("focused") && !focused) return false;
        return true;
    }

    /** Gửi 1 lần tương tác (đóng/mở) vào cửa sập tại pos. */
    private static void interact(MinecraftClient mc, ClientPlayerEntity player, BlockPos pos) {
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
        ActionResult result = mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) player.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------------ MIC

    private static boolean isOn(String v, boolean def) {
        if (v == null) return def;
        v = v.trim().toLowerCase();
        if (v.equals("on") || v.equals("true") || v.equals("1")) return true;
        if (v.equals("off") || v.equals("false") || v.equals("0")) return false;
        return def;
    }

    private static double parseNum(String v, double def) {
        try { return v == null ? def : Double.parseDouble(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    private static boolean sleepQuiet(long ms) {
        try { Thread.sleep(ms); return true; } catch (InterruptedException e) { return false; }
    }

    private static int pct(double v) { return (int) Math.round(v * 100.0); }

    /** Mở mic: 16-bit mono ở tần số rate. Trả null nếu không mở được. */
    private static TargetDataLine openMic(float rate, String device) {
        try {
            AudioFormat fmt = new AudioFormat(rate, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, fmt);
            TargetDataLine line = null;
            String want = device.toLowerCase();
            if (!want.isEmpty()) {
                for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                    if (!mi.getName().toLowerCase().contains(want)) continue;
                    Mixer mx = AudioSystem.getMixer(mi);
                    if (mx.isLineSupported(info)) {
                        line = (TargetDataLine) mx.getLine(info);
                        LOG.info("Auto Trapdoor: dung mic '{}'", mi.getName());
                        break;
                    }
                }
            }
            if (line == null) {
                if (!AudioSystem.isLineSupported(info)) return null;
                line = (TargetDataLine) AudioSystem.getLine(info);
                LOG.info("Auto Trapdoor: dung mic mac dinh cua he thong");
            }
            int chunk = ((int) (rate * 0.005)) * 2;      // 5ms
            line.open(fmt, chunk * 8);                   // buffer nho (40ms) -> do tre thap
            line.start();
            return line;
        } catch (Throwable e) {
            LOG.warn("Auto Trapdoor: khong mo duoc mic o {} Hz: {}", rate, e.toString());
            return null;
        }
    }

    /** Vòng ngoài: tự mở lại mic khi mất/đổi thiết bị, tự nhàn rỗi khi mic=off. */
    private static void micLoop() {
        final float[] rates = {44100f, 48000f, 16000f};
        long wait = 2000L;
        boolean failLogged = false;
        boolean listed = false;
        while (true) {
            if (!micOn) {
                if (!sleepQuiet(1000)) return;
                maybeReloadConfig();
                continue;
            }
            TargetDataLine line = null;
            try {
                if (micDebug && !listed) {
                    listed = true;
                    for (Mixer.Info mi : AudioSystem.getMixerInfo()) LOG.info("Auto Trapdoor: thiet bi am thanh: '{}'", mi.getName());
                }
                String dev = micDevice;
                for (float rate : rates) {
                    line = openMic(rate, dev);
                    if (line != null) break;
                }
                if (line == null) {
                    if (!failLogged) {
                        LOG.error("Auto Trapdoor: khong mo duoc mic nao (kiem tra quyen Microphone cua he dieu hanh). Se tu thu lai.");
                        failLogged = true;
                    }
                    if (!sleepQuiet(wait)) return;
                    wait = Math.min(wait * 2, 15000L);
                    maybeReloadConfig();
                    continue;
                }
                failLogged = false;
                wait = 2000L;
                runMic(line, dev);
                if (micOn) LOG.warn("Auto Trapdoor: mic dung, mo lai sau 2 giay...");
            } catch (LinkageError e) {
                LOG.error("Auto Trapdoor: thieu thu vien am thanh (java.desktop), tat tinh nang mic", e);
                return;
            } catch (Throwable e) {
                LOG.error("Auto Trapdoor: loi luong mic", e);
            } finally {
                activeLine = null;
                if (line != null) {
                    try { line.stop(); } catch (Throwable ignored) { }
                    try { line.close(); } catch (Throwable ignored) { }
                }
            }
            if (!sleepQuiet(2000)) return;
        }
    }

    /** Đọc mic từng khối 5ms cho tới khi mic dừng / đổi config. */
    private static void runMic(TargetDataLine line, String openedDevice) {
        AudioFormat fmt = line.getFormat();
        byte[] buf = new byte[((int) (fmt.getSampleRate() * 0.005)) * 2];
        final int chunkMs = 5;
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean hasTrigger = false;
        long lastTrigger = 0L;
        int aboveMs = 0;
        double holdPeak = 0.0;
        long holdUntil = 0L, meterT = 0L, flashUntil = 0L;
        long cfgT = System.nanoTime(), dbgT = cfgT;
        int dbgPeak = 0;

        activeLine = line;
        lastChunkNanos = System.nanoTime();
        LOG.info("Auto Trapdoor: dang nghe mic ({} Hz, nguong {}%).", (int) fmt.getSampleRate(), pct(micThreshold));

        while (micOn) {
            int n = line.read(buf, 0, buf.length);
            long now = System.nanoTime();
            if (n <= 0) {
                if (!line.isOpen() || !line.isActive()) break;   // mic bi dung/rut -> mo lai
                continue;
            }
            lastChunkNanos = now;

            int peak = 0;
            for (int i = 0; i + 1 < n; i += 2) {
                int v = (short) ((buf[i + 1] << 8) | (buf[i] & 0xFF));
                if (v < 0) v = -v;
                if (v > peak) peak = v;
            }
            double level = peak / 32768.0;
            publishPeak(level);
            double thr = micThreshold;

            if (now - cfgT >= 1_000_000_000L) {              // ~1 lan/giay: nap lai config
                cfgT = now;
                maybeReloadConfig();
                if (!micDevice.equalsIgnoreCase(openedDevice)) break;   // doi mic -> mo lai
            }

            if (micDebug) {
                if (peak > dbgPeak) dbgPeak = peak;
                if (now - dbgT >= 1_000_000_000L) {
                    LOG.info("Auto Trapdoor mic: dinh {}% (nguong {}%)", Math.round(dbgPeak / 327.68), pct(thr));
                    dbgPeak = 0;
                    dbgT = now;
                }
            }

            // Kich hoat: du to (va du lau neu mic_min_ms > 0) + het thoi gian cho
            if (level >= thr) aboveMs += chunkMs; else aboveMs = 0;
            boolean cooled = !hasTrigger || now - lastTrigger >= micCooldownMs * 1_000_000L;
            if (aboveMs > 0 && aboveMs >= micMinMs && cooled) {
                hasTrigger = true;
                lastTrigger = now;
                flashUntil = now + 600_000_000L;
                pendingUntil = 0L;
                final long t0 = now;
                mc.execute(() -> micTriggerTask(t0));
            } else if (pendingUntil != 0L) {
                mc.execute(AutoTrapdoorClient::micRetryTask);   // chua co cua nao mo -> thu lai moi khoi 5ms
            }

            // Dong ho do tren action bar (de chinh nguong)
            if (micMeter) {
                if (level >= holdPeak || now - holdUntil > 0L) {
                    holdPeak = level;
                    holdUntil = now + 1_500_000_000L;
                }
                if (now - meterT >= 120_000_000L) {
                    meterT = now;
                    final String msg = "Mic " + pct(level) + "% | giu " + pct(holdPeak) + "% | nguong " + pct(thr) + "%"
                            + (now - flashUntil < 0L ? "  >> KICH HOAT" : "");
                    mc.execute(() -> {
                        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), true);
                    });
                }
            }
        }
    }

    /** Lần thử đầu tiên (luồng chính). Không có cửa mở -> bật chế độ thử lại trong mic_retry_ms. */
    private static void micTriggerTask(long triggerNanos) {
        if (closeSafely()) {
            pendingUntil = 0L;
            return;
        }
        long retry = micRetryMs * 1_000_000L;
        if (retry > 0L) pendingUntil = triggerNanos + retry;
    }

    /** Thử lại (luồng chính) cho tới khi đóng được hoặc hết hạn. */
    private static void micRetryTask() {
        long until = pendingUntil;
        if (until == 0L) return;
        if (System.nanoTime() - until > 0L) {
            pendingUntil = 0L;
            return;
        }
        if (closeSafely()) pendingUntil = 0L;
    }

    /** Nếu mic đang mở mà 3 giây không có khối âm thanh nào (rút/hỏng thiết bị) -> dừng line để vòng ngoài mở lại. */
    private static void micWatchdog() {
        while (true) {
            if (!sleepQuiet(1000)) return;
            TargetDataLine l = activeLine;
            if (l != null && System.nanoTime() - lastChunkNanos > 3_000_000_000L) {
                LOG.warn("Auto Trapdoor: mic khong con du lieu, dang mo lai.");
                try { l.stop(); } catch (Throwable ignored) { }
            }
        }
    }
}
