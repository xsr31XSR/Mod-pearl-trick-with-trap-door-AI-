package com.example.autotrapdoor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

/** Màn hình cấu hình trong game. Chỉnh là áp dụng ngay; đóng màn hình thì tự lưu vào file config. */
public class ConfigScreen extends Screen {
    private static final int GREEN = 0xFF3CC84B;
    private static final int RED = 0xFFE5484D;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int YELLOW = 0xFFFFD33D;
    private static final int DARK = 0xFF1E1E1E;
    private static final int BORDER = 0xFF555555;

    private final List<String> mics = AutoTrapdoorClient.listMics();

    private Sl thresholdSlider;
    private ButtonWidget talkBtn;
    private ButtonWidget trigBtn;
    private int meterY;
    private int titleY;

    private double cur = 0.0;
    private double hold = 0.0;
    private long holdUntil = 0L;

    private int calibMode = 0;          // 0 = không đo, 1 = nói chuyện, 2 = câu kích hoạt
    private long calibEnd = 0L;
    private double calibMax = 0.0;
    private double talkPeak = -1.0;
    private double trigPeak = -1.0;
    private String calibMsg = "";

    public ConfigScreen() {
        super(Text.literal("Auto Trapdoor"));
    }

    @Override
    protected void init() {
        AutoTrapdoorClient.takePeak();   // xả đỉnh cũ

        final int lx = this.width / 2 - 155;
        final int rx = this.width / 2 + 5;
        final int w = 150;
        final int top = Math.max(24, this.height / 2 - 100);
        titleY = top - 16;

        // Hàng 0: bật/tắt mic + chọn thiết bị
        btn(micLabel(), lx, top, w, b -> {
            AutoTrapdoorClient.micOn = !AutoTrapdoorClient.micOn;
            b.setMessage(micLabel());
        });
        btn(devLabel(), rx, top, w, b -> {
            cycleDevice();
            b.setMessage(devLabel());
        });

        // Hàng 1: ngưỡng
        thresholdSlider = new Sl(lx, top + 24, 310, "Ngưỡng kích hoạt (thấp = nhạy)", "%",
                1, 100, 1, pct(AutoTrapdoorClient.micThreshold),
                v -> AutoTrapdoorClient.micThreshold = v / 100.0);
        addDrawableChild(thresholdSlider);

        // Hàng 2: giữ tối thiểu + hồi
        addDrawableChild(new Sl(lx, top + 48, w, "Giữ tối thiểu", " ms",
                0, 200, 5, AutoTrapdoorClient.micMinMs,
                v -> AutoTrapdoorClient.micMinMs = (long) v));
        addDrawableChild(new Sl(rx, top + 48, w, "Hồi sau mỗi lần", " ms",
                0, 1000, 25, AutoTrapdoorClient.micCooldownMs,
                v -> AutoTrapdoorClient.micCooldownMs = (long) v));

        // Hàng 3: thử lại + chế độ chạy
        addDrawableChild(new Sl(lx, top + 72, w, "Thử lại", " ms",
                0, 500, 10, AutoTrapdoorClient.micRetryMs,
                v -> AutoTrapdoorClient.micRetryMs = (long) v));
        btn(modeLabel(), rx, top + 72, w, b -> {
            AutoTrapdoorClient.mode = nextOf(AutoTrapdoorClient.mode, "always", "unfocused", "focused");
            b.setMessage(modeLabel());
        });

        // Hàng 4: chọn cửa  /  Hàng 5: đo ngưỡng tự động
        btn(selectLabel(), lx, top + 96, 310, b -> {
            AutoTrapdoorClient.select = nextOf(AutoTrapdoorClient.select, "look", "nearest");
            b.setMessage(selectLabel());
        });

        talkBtn = btn(talkLabel(), lx, top + 120, w, b -> startCalib(1));
        trigBtn = btn(trigLabel(), rx, top + 120, w, b -> startCalib(2));

        meterY = top + 152;
        btn(Text.literal("Xong (tự lưu)"), this.width / 2 - 100, meterY + 44, 200, b -> this.close());
    }

    private ButtonWidget btn(Text text, int x, int y, int w, ButtonWidget.PressAction action) {
        return addDrawableChild(ButtonWidget.builder(text, action).dimensions(x, y, w, 20).build());
    }

    // ------------------------------------------------------------ nhãn

    private Text micLabel() {
        return Text.literal("Mic: " + (AutoTrapdoorClient.micOn ? "BẬT" : "TẮT"));
    }

    private Text devLabel() {
        String d = AutoTrapdoorClient.micDevice;
        String s = d.isEmpty() ? "mặc định" : (d.length() > 16 ? d.substring(0, 16) + "..." : d);
        return Text.literal("Thiết bị: " + s);
    }

    private Text modeLabel() {
        String m = AutoTrapdoorClient.mode;
        String s = m.equals("unfocused") ? "khi không focus" : m.equals("focused") ? "khi đang focus" : "luôn luôn";
        return Text.literal("Chạy: " + s);
    }

    private Text selectLabel() {
        return Text.literal("Chọn cửa sập: " + (AutoTrapdoorClient.select.equals("nearest") ? "gần người nhất" : "gần tâm màn hình nhất"));
    }

    private Text talkLabel() { return Text.literal("1) Đo nói chuyện"); }

    private Text trigLabel() { return Text.literal("2) Đo câu kích hoạt"); }

    private static String nextOf(String current, String... values) {
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) return values[(i + 1) % values.length];
        }
        return values[0];
    }

    private void cycleDevice() {
        List<String> opts = new ArrayList<>();
        opts.add("");
        opts.addAll(mics);
        int idx = 0;
        for (int i = 0; i < opts.size(); i++) {
            if (opts.get(i).equalsIgnoreCase(AutoTrapdoorClient.micDevice)) { idx = i; break; }
        }
        AutoTrapdoorClient.micDevice = opts.get((idx + 1) % opts.size());
    }

    private static int pct(double v) {
        return (int) Math.round(v * 100.0);
    }

    // ------------------------------------------------------------ đo tự động

    private void startCalib(int mode) {
        if (!AutoTrapdoorClient.isMicRunning()) {
            calibMsg = "Mic chưa chạy: bật Mic và chọn đúng thiết bị.";
            return;
        }
        AutoTrapdoorClient.takePeak();
        calibMode = mode;
        calibEnd = System.nanoTime() + 5_000_000_000L;
        calibMax = 0.0;
        calibMsg = mode == 1 ? "Nói chuyện bình thường như với bạn bè..." : "Nói câu kích hoạt như khi chơi...";
    }

    private void finishCalib() {
        int mode = calibMode;
        calibMode = 0;
        talkBtn.setMessage(talkLabel());
        trigBtn.setMessage(trigLabel());

        if (calibMax <= 0.0) {
            calibMsg = "Mic im lặng (0%): kiểm tra thiết bị / quyền mic.";
            return;
        }
        if (mode == 1) talkPeak = calibMax; else trigPeak = calibMax;

        if (talkPeak < 0.0 || trigPeak < 0.0) {
            calibMsg = (mode == 1 ? "Nói chuyện: " : "Kích hoạt: ") + pct(calibMax) + "%. Đo nốt bước còn lại.";
            return;
        }
        if (trigPeak <= talkPeak + 0.03) {
            calibMsg = "Quá sát (nói chuyện " + pct(talkPeak) + "%, kích hoạt " + pct(trigPeak) + "%). Nói dứt khoát/to hơn khi kích hoạt.";
            return;
        }
        double thr = talkPeak + (trigPeak - talkPeak) * 0.5;
        thresholdSlider.setReal(pct(thr));
        calibMsg = "Đã đặt ngưỡng " + pct(thr) + "% (nói chuyện " + pct(talkPeak) + "%, kích hoạt " + pct(trigPeak) + "%).";
    }

    // ------------------------------------------------------------ vòng đời

    @Override
    public void tick() {
        double p = AutoTrapdoorClient.takePeak();
        long now = System.nanoTime();
        cur = p;
        if (p >= hold || now - holdUntil > 0L) {
            hold = p;
            holdUntil = now + 1_500_000_000L;
        }
        if (calibMode != 0) {
            if (p > calibMax) calibMax = p;
            long left = calibEnd - now;
            if (left <= 0L) {
                finishCalib();
            } else {
                Text t = Text.literal("Đang đo... " + (int) Math.ceil(left / 1.0E9) + "s");
                if (calibMode == 1) talkBtn.setMessage(t); else trigBtn.setMessage(t);
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, titleY, WHITE);

        final int bx = this.width / 2 - 155;
        final int bw = 310;
        final int bh = 14;
        final int by = meterY;
        double thr = AutoTrapdoorClient.micThreshold;

        ctx.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, BORDER);
        ctx.fill(bx, by, bx + bw, by + bh, DARK);
        int lv = (int) Math.round(Math.min(1.0, cur) * bw);
        ctx.fill(bx, by, bx + lv, by + bh, cur >= thr ? RED : GREEN);
        int hx = bx + (int) Math.round(Math.min(1.0, hold) * bw);
        ctx.fill(hx - 1, by, hx + 1, by + bh, YELLOW);
        int tx = bx + (int) Math.round(thr * bw);
        ctx.fill(tx - 1, by - 3, tx + 1, by + bh + 3, WHITE);

        String info = "Mic " + pct(cur) + "%   |   giữ " + pct(hold) + "%   |   ngưỡng " + pct(thr) + "%";
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(info), this.width / 2, by + bh + 6, GRAY);
        if (!calibMsg.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(calibMsg), this.width / 2, by + bh + 18, YELLOW);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;   // không dừng game
    }

    @Override
    public void removed() {
        super.removed();
        AutoTrapdoorClient.saveConfig();
    }

    // ------------------------------------------------------------ thanh trượt

    private static final class Sl extends SliderWidget {
        private final String label;
        private final String unit;
        private final double min;
        private final double max;
        private final double step;
        private final DoubleConsumer onSet;

        Sl(int x, int y, int w, String label, String unit, double min, double max, double step, double cur, DoubleConsumer onSet) {
            super(x, y, w, 20, Text.literal(""), Math.max(0.0, Math.min(1.0, (cur - min) / (max - min))));
            this.label = label;
            this.unit = unit;
            this.min = min;
            this.max = max;
            this.step = step;
            this.onSet = onSet;
            updateMessage();
        }

        private double real() {
            double v = min + this.value * (max - min);
            return Math.max(min, Math.min(max, Math.round(v / step) * step));
        }

        void setReal(double v) {
            this.value = Math.max(0.0, Math.min(1.0, (v - min) / (max - min)));
            updateMessage();
            applyValue();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + (long) Math.round(real()) + unit));
        }

        @Override
        protected void applyValue() {
            onSet.accept(real());
        }
    }
}
