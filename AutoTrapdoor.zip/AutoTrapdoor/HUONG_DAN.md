# Auto Trapdoor (Fabric 1.21.11)

Nhấn **1 phím** → mod tự tìm cửa sập (trapdoor) **đang mở, gần nhất** trong tầm với và đóng lại.
Phím là **phím toàn cục**: vẫn hoạt động khi bạn đang ở cửa sổ khác / alt-tab.

## Cách build
1. Cài **JDK 21**.
2. Mở thư mục này trong terminal, chạy:
   - Windows: `gradlew build` (nếu chưa có wrapper: cài Gradle 9.x rồi chạy `gradle wrapper` trước)
   - Linux/Mac: `./gradlew build`
3. File mod nằm ở `build/libs/autotrapdoor-1.3.0.jar` (dùng file KHÔNG có đuôi `-sources`).

## Cách cài
1. Cài **Fabric Loader** cho Minecraft **1.21.11**.
2. Bỏ `Fabric API` và `autotrapdoor-1.3.0.jar` vào thư mục `mods`.
3. Vào game.

## Cách dùng
- Đứng gần cửa sập đang mở (trong ~4.5 block), nhấn **F8**.
- Mod đóng cái gần nhất; nhấn lần nữa để đóng cái tiếp theo.
- Để dùng khi alt-tab ở **singleplayer**: nhấn `F3 + P` trong game để tắt "tạm dừng khi mất focus", nếu không game sẽ pause.
- Đổi phím: sửa `config/autotrapdoor.properties` (dòng `key=F8`, ví dụ `key=Z`, `key=F9`, `key=INSERT`), rồi khởi động lại game.

## Lưu ý
- Cửa sập **sắt** không mở/đóng bằng tay được nên bị bỏ qua.
- Đang giữ Shift có thể làm tương tác bị coi là đặt block thay vì đóng cửa.
- **macOS**: cấp quyền *Accessibility / Input Monitoring* cho Java/launcher. **Linux Wayland**: phím toàn cục thường không hoạt động (dùng X11).
- Trên server nhiều nơi cấm macro/auto-click: hãy kiểm tra luật server trước khi dùng. Mod chỉ lắng nghe đúng 1 phím đã cấu hình.

## Chơi 2 acc (acc chính + acc phụ)
Mở 2 cửa sổ Minecraft, cả 2 đều cài mod. Vì phím là toàn cục nên nhấn F8 sẽ làm CẢ HAI acc phản ứng. Để chỉ acc phụ đóng cửa:

**Cách 1 (khuyên dùng): chế độ `unfocused`** – trong `config/autotrapdoor.properties` đặt:
```
key=F8
mode=unfocused
```
Mod chỉ chạy ở cửa sổ **không được focus**. Khi bạn đang chơi acc chính (đang focus), nhấn F8 → chỉ acc phụ (nền) đóng cửa. Dùng được cả khi 2 acc dùng chung thư mục `.minecraft`.

**Cách 2: mỗi acc một phím** – tạo 2 instance riêng (config riêng): acc phụ `key=F8`, acc chính bỏ mod hoặc đặt phím khác (ví dụ `key=F9`).

Các giá trị `mode`: `always` (luôn chạy), `unfocused` (chỉ cửa sổ nền), `focused` (chỉ cửa sổ đang focus).

Acc phụ cần: đứng trong tầm 4.5 block của cửa sập, không giữ Shift, và (nếu singleplayer/LAN) đã tắt pause khi mất focus bằng `F3 + P`.

## Chọn đúng 1 cửa sập khi có nhiều cái trong tầm
Trong `config/autotrapdoor.properties`:
```
select=look
```
- `look` (mặc định): đóng cửa sập **gần tâm màn hình nhất** -> hãy quay mặt/nhắm vào cửa sập muốn đóng rồi nhấn phím. Với acc phụ, hãy xoay acc phụ hướng về cửa sập cần đóng.
- `nearest`: đóng cái gần người nhất (như bản cũ).

## Tự đóng bằng mic (v1.3.0)
Mod nghe mic của máy. Khi âm thanh đủ to (đỉnh >= ngưỡng) -> chạy **cùng đường với nhấn phím** (tự đóng cửa sập theo `select`, tôn trọng `mode`). Mỗi khối âm thanh 10ms được kiểm tra liên tục, không chờ tick.

Trong `config/autotrapdoor.properties`:
```
mic=on
mic_threshold=30
mic_cooldown_ms=400
mic_device=
mic_debug=off
```
- `mic=off` để tắt hẳn (khi tắt mod không mở mic).
- `mic_threshold`: ngưỡng 0-100 (% biên độ tối đa). Thấp = nhạy hơn.
- **Chỉnh ngưỡng:** đặt `mic_debug=on`, vào game, tạo tiếng động rồi xem `logs/latest.log` dòng `Auto Trapdoor mic: dinh X%` mỗi giây. Đặt ngưỡng giữa mức tiếng ồn nền và mức tiếng cần bắt.
- Sau mỗi lần kích hoạt phải im lại (xuống dưới nửa ngưỡng) và qua `mic_cooldown_ms` mới kích hoạt tiếp, nên tiếng ồn kéo dài không bị spam.
- `mic_device`: một phần tên mic muốn dùng (không phân biệt hoa thường); để trống = mic mặc định. Với `mic_debug=on`, log liệt kê tên các thiết bị âm thanh lúc khởi động để copy tên.
- Windows: Settings > Privacy > Microphone, bật cho ứng dụng desktop. macOS: cấp quyền Microphone cho Java/launcher. Nếu bị chặn, mic trả về im lặng (log hiện đỉnh 0%).
- Chơi 2 acc: mic nghe chung cho cả 2 cửa sổ -> đặt `mode=unfocused` để chỉ acc nền phản ứng.

