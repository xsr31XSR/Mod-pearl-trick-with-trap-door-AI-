# Auto Trapdoor (Fabric 1.21.11)

Nhấn **1 phím** → mod tự tìm cửa sập (trapdoor) **đang mở, gần nhất** trong tầm với và đóng lại.
Phím là **phím toàn cục**: vẫn hoạt động khi bạn đang ở cửa sổ khác / alt-tab.

## Cách build
1. Cài **JDK 21**.
2. Mở thư mục này trong terminal, chạy:
   - Windows: `gradlew build` (nếu chưa có wrapper: cài Gradle 9.x rồi chạy `gradle wrapper` trước)
   - Linux/Mac: `./gradlew build`
3. File mod nằm ở `build/libs/autotrapdoor-1.5.0.jar` (dùng file KHÔNG có đuôi `-sources`).

## Cách cài
1. Cài **Fabric Loader** cho Minecraft **1.21.11**.
2. Bỏ `Fabric API` và `autotrapdoor-1.5.0.jar` vào thư mục `mods`.
3. Vào game.

## Cách dùng
- Đứng gần cửa sập đang mở (trong ~4.5 block), nhấn **F8**.
- Mod đóng cái gần nhất; nhấn lần nữa để đóng cái tiếp theo.
- Để dùng khi alt-tab ở **singleplayer**: nhấn `F3 + P` trong game để tắt "tạm dừng khi mất focus", nếu không game sẽ pause.
- Đổi phím: sửa `config/autotrapdoor.properties` (dòng `key=F8`, ví dụ `key=Z`, `key=F9`, `key=INSERT`), rồi khởi động lại game.

## Lưu ý
- Cửa sập **sắt** không mở/đóng bằng tay được nên bị bỏ qua.
- Đang giữ Shift có thể làm tương tác bị coi là đặt block thay vì đóng cửa.
- **macOS**: cấp quyền *Accessibility / Input Monitoring* cho Java/launcher. **Linux Wayland**: phím toàn cục thường không hoạt động (dùng X11).
- Trên server nhiều nơi cấm macro/auto-click: hãy kiểm tra luật server trước khi dùng. Mod chỉ lắng nghe đúng 1 phím đã cấu hình.

## Chơi 2 acc (acc chính + acc phụ)
Mở 2 cửa sổ Minecraft, cả 2 đều cài mod. Vì phím là toàn cục nên nhấn F8 sẽ làm CẢ HAI acc phản ứng. Để chỉ acc phụ đóng cửa:

**Cách 1 (khuyên dùng): chế độ `unfocused`** – trong `config/autotrapdoor.properties` đặt:
```
key=F8
mode=unfocused
```
Mod chỉ chạy ở cửa sổ **không được focus**. Khi bạn đang chơi acc chính (đang focus), nhấn F8 → chỉ acc phụ (nền) đóng cửa. Dùng được cả khi 2 acc dùng chung thư mục `.minecraft`.

**Cách 2: mỗi acc một phím** – tạo 2 instance riêng (config riêng): acc phụ `key=F8`, acc chính bỏ mod hoặc đặt phím khác (ví dụ `key=F9`).

Các giá trị `mode`: `always` (luôn chạy), `unfocused` (chỉ cửa sổ nền), `focused` (chỉ cửa sổ đang focus).

Acc phụ cần: đứng trong tầm 4.5 block của cửa sập, không giữ Shift, và (nếu singleplayer/LAN) đã tắt pause khi mất focus bằng `F3 + P`.

## Chọn đúng 1 cửa sập khi có nhiều cái trong tầm
Trong `config/autotrapdoor.properties`:
```
select=look
```
- `look` (mặc định): đóng cửa sập **gần tâm màn hình nhất** -> hãy quay mặt/nhắm vào cửa sập muốn đóng rồi nhấn phím. Với acc phụ, hãy xoay acc phụ hướng về cửa sập cần đóng.
- `nearest`: đóng cái gần người nhất (như bản cũ).

## Màn hình cấu hình trong game (v1.5.0)
Mở bằng phím **F7** (phím toàn cục, chỉ mở khi cửa sổ game đang focus và không mở màn hình khác) hoặc lệnh **/autotrapdoor** trong chat. Chỉnh là **áp dụng ngay**, đóng màn hình (Xong / ESC / F7) là tự lưu vào config.
- **Mic BẬT/TẮT**, **Thiết bị**: bấm để đổi qua từng mic (mặc định = mic của hệ thống).
- **Ngưỡng kích hoạt**: thấp = nhạy. Thanh đo dưới cùng: xanh/đỏ = mức hiện tại, vạch vàng = đỉnh giữ 1.5 giây, vạch trắng = ngưỡng. Đỏ nghĩa là đang vượt ngưỡng.
- **Giữ tối thiểu**: âm phải liên tục vượt ngưỡng ngần ấy ms mới kích hoạt (0 = tắt, mỗi 5ms thêm vào chậm thêm 5ms).
- **Hồi sau mỗi lần**: thời gian chờ giữa 2 lần kích hoạt.
- **Thử lại**: nghe thấy mà chưa có cửa sập mở thì tiếp tục thử trong ngần ấy ms.
- **Chạy**: luôn luôn / khi không focus (acc nền) / khi đang focus. **Chọn cửa sập**: gần tâm màn hình / gần người nhất.
- **Đo tự động ngưỡng**: bấm "1) Đo nói chuyện", nói chuyện bình thường 5 giây; rồi "2) Đo câu kích hoạt", nói câu kích hoạt 5 giây. Mod đặt ngưỡng ở giữa hai mức. Nếu hai mức quá sát sẽ báo, lúc đó tăng "Giữ tối thiểu".
- Config thêm `gui_key=F7` (đổi phím) hoặc `gui_key=NONE` (tắt phím, vẫn dùng được lệnh).

## Tự đóng bằng mic (v1.5.0)
Mod nghe mic của máy. Khi âm thanh đủ to (đỉnh >= ngưỡng) -> chạy **cùng đường với nhấn phím** (đóng cửa sập theo `select`, tôn trọng `mode`). Mỗi khối **5ms** được kiểm tra liên tục.

Mọi tuỳ chọn có thể chỉnh trong màn hình cấu hình (F7) hoặc sửa file `config/autotrapdoor.properties` (**sửa file là có hiệu lực ngay khi đang chơi**, riêng `key`/`gui_key` cần khởi động lại):
```
mic=on
mic_threshold=30
mic_cooldown_ms=300
mic_min_ms=0
mic_retry_ms=200
mic_device=
mic_debug=off
mic_meter=off
```
- `mic_meter=on`: hiện mức mic trên action bar (không cần mở GUI).
- `mic_debug=on`: ghi mức mic mỗi giây và danh sách thiết bị vào `logs/latest.log`.

**Ổn định:** mic bị rút/đổi thiết bị sẽ tự mở lại; không có dữ liệu 3 giây thì tự mở lại; lỗi bất ngờ khi đóng cửa chỉ ghi log, không làm crash; file config ghi qua file tạm nên không bị hỏng khi tắt đột ngột.

Quyền mic: Windows Settings > Privacy > Microphone, bật cho ứng dụng desktop. macOS: cấp quyền Microphone cho Java/launcher. Bị chặn thì mic trả về im lặng. Chơi 2 acc: đặt `mode=unfocused` để chỉ acc nền phản ứng.

